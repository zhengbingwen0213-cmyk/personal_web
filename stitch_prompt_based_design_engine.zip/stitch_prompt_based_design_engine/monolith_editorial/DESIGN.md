---
name: Monolith Editorial
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1b1b1b'
  on-surface-variant: '#4c4546'
  inverse-surface: '#303030'
  inverse-on-surface: '#f1f1f1'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dfe0e0'
  on-secondary-container: '#616363'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1b1b'
  on-tertiary-container: '#848484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1b1b1b'
  on-tertiary-fixed-variant: '#474747'
  background: '#f9f9f9'
  on-background: '#1b1b1b'
  surface-variant: '#e2e2e2'
  border-hairline: '#E5E5E5'
  text-secondary: '#737373'
  paper-grain: '#F9F9F9'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 120px
    fontWeight: '700'
    lineHeight: 110px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 68px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.1em
  label-mono-lg:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
spacing:
  container-max: 1200px
  gutter: 32px
  margin-mobile: 20px
  rule-thick: 4px
  rule-thin: 1px
  section-padding: 120px
---

## Brand & Style

The design system is an exercise in **Refined Minimalism**, drawing heavily from high-end architectural monographs and museum catalogs. It is austere, authoritative, and intellectual, prioritizing typography as the primary visual asset over imagery.

The aesthetic is built on the concept of "The Grid and the Rule." It utilizes a strict monochrome palette to remove distractions, forcing the user's focus onto the content and the rhythm of the layout. The personality is confident and dramatic, using extreme scale—oversized typography contrasted with tiny monospace metadata—to create a sense of hierarchy and tension. 

Key style markers include:
- **Zero-radius geometry**: Every element is perfectly rectangular.
- **Editorial pacing**: Generous white space (negative space) is used to frame information.
- **Structural visibility**: Hairline borders and thick rules are not just dividers but active participants in the composition.
- **Tactile sterility**: A subtle paper-like texture prevents the digital canvas from feeling "flat," adding a physical quality to the monochrome environment.

## Colors

The palette is strictly limited to binary extremes. Color is never used to convey meaning; instead, contrast and weight handle all functional signaling.

- **Primary**: Pure Black (#000000). Used for primary headings, thick rules, and inverted section backgrounds.
- **Secondary**: Pure White (#FFFFFF). Used for the primary canvas and text within inverted (black) blocks.
- **Neutral/Utility**: A range of cool grays is used exclusively for secondary metadata and hairline dividers to prevent the UI from becoming visually overwhelming.

**State Management**:
- **Interactions**: Use color inversion (Black → White background) to indicate active states or hover effects.
- **Emphasis**: "Inverted" sections (Black background with White text) should be used for specific content blocks like 'Skills' or 'Contact' to create a dramatic break in the scroll.

## Typography

This design system uses a triple-font approach to define its editorial character:
1. **Playfair Display**: The emotional core. Used for display titles and hero sections. High contrast between thick and thin strokes provides the "luxury" feel.
2. **Source Serif 4**: The functional core. Used for all long-form reading and summary text. It offers high legibility while maintaining the sophisticated serif aesthetic.
3. **JetBrains Mono**: The technical layer. Used for section numbers (e.g., 01, 02), dates, tags, and small metadata. This provides a "blueprinted" or "cataloged" feel to the portfolio.

**Formatting Rules**:
- **Capitalization**: Labels and Mono-text should always be uppercase with slight letter-spacing.
- **Section Numbers**: Always use leading zeros (01, 02) in JetBrains Mono to anchor section headings.

## Layout & Spacing

The layout follows a **Fixed Editorial Grid** with 12 columns for desktop and a single column for mobile. 

- **The Rule as Structure**: Sections are separated by a `rule-thick` (4px) horizontal black line. Internal components (like table rows or card edges) use `rule-thin` (1px) hairlines.
- **The "Identity Panel"**: In the Hero, a large bordered square or rectangular frame serves as a typographic placeholder for an image. It should align to the right side of the 12-column grid.
- **Pacing**: Use large `section-padding` (120px) to give content room to breathe. On mobile, this scales down to 64px.
- **Alignment**: Flush-left alignment is preferred for most copy, while section indexes are often offset to the far left gutter to act as visual anchors.

## Elevation & Depth

This design system is strictly **Flat**. There are no shadows, blurs, or gradients used to create depth.

Hierarchy is achieved through **Tonal Inversion** and **Borders**:
- **Foreground elements**: Defined by `rule-thin` black outlines.
- **Depth layers**: Instead of a shadow, a highlighted element (like a card on hover) should invert its colors entirely (Background: Black, Text: White).
- **Background Texture**: To avoid a clinical digital feel, apply a very low-opacity (2-3%) "paper grain" or "dotted grid" texture to the global background. This texture remains static during scroll.

## Shapes

The shape language is **Sharp**. 

- **Corner Radius**: 0px for all elements (Buttons, Cards, Inputs, Frames).
- **Geometry**: Use perfect squares and rectangles. Any "ornamentation" should be geometric, such as a 45-degree slash or a simple square bullet point, all maintaining sharp 90-degree corners.

## Components

### Buttons
- **Primary**: Solid Black background, White JetBrains Mono text (Uppercase). Sharp corners. No shadow.
- **Ghost**: Pure White background, Black 1px border, Black text. Inverts on hover.

### Project Cards
- Defined by a `rule-thin` black border on all sides.
- No padding inside the card for titles; titles should be separated by an internal horizontal rule.
- On hover: The entire card background turns Black and text turns White instantly.

### Chips & Tags (Skills)
- Small rectangular boxes with 1px black borders.
- Text: JetBrains Mono, 10px or 12px, Uppercase.
- Stacking: Should be arranged in a tight grid or a justified row.

### Timeline (Experience)
- A series of full-width rows separated by 1px horizontal hairlines.
- Columns: Date (Left, Mono), Organization (Center, Serif Bold), Description (Right, Serif).

### Form Inputs
- 1px Black bottom-border only (underline style). 
- Label sits above in small Monospace.
- Focus state: The bottom border increases to 2px thickness.

### Section Header
- A combination of a `rule-thick` line, followed by a Monospace section number (e.g., 01), and a large Playfair Display headline.